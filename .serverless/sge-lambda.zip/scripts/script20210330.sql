ALTER TABLE  `registrations` ADD `year` INT(4);
UPDATE `registrations` SET `year`=2020;