INSERT INTO `sucursals` (`id`,`code`,`description`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (1,'001','Externato Luz do Dia',1,1,NULL,1,'2019-11-25 11:00:00','2019-11-25 11:00:00','2019-11-25 11:00:00');
INSERT INTO `sucursals` (`id`,`code`,`description`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (2,'002','Centro Infantil Luz do Dia',1,1,NULL,1,'2019-11-25 11:00:00','2019-11-25 11:00:00','2019-11-25 11:00:00');
INSERT INTO `frequencies` (`level`,`description`,`specialHourMonthlyValue`,`recurigRegistrationValue`,`registrationValue`, `monthlyPayment`,`sucursal_id`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (1,'Primeira  Classe','0.0', '0.0','0.0', '0.0',1,1,1,NULL,1,'2019-11-25 17:00:00','2019-11-25 17:00:00','2019-11-25 17:00:00');
INSERT INTO `frequencies` (`level`,`description`,`specialHourMonthlyValue`,`recurigRegistrationValue`,`registrationValue`, `monthlyPayment`,`sucursal_id`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (2,'Segunda  Classe','0.0', '0.0','0.0', '0.0',1,1,1,NULL,1,'2019-11-25 17:00:00','2019-11-25 17:00:00','2019-11-25 17:00:00');
INSERT INTO `frequencies` (`level`,`description`,`specialHourMonthlyValue`,`recurigRegistrationValue`,`registrationValue`, `monthlyPayment`,`sucursal_id`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (3,'Terceirea  Classe','0.0', '0.0','0.0', '0.0',1,1,1,NULL,1,'2019-11-25 17:00:00','2019-11-25 17:00:00','2019-11-25 17:00:00');
INSERT INTO `frequencies` (`level`,`description`,`specialHourMonthlyValue`,`recurigRegistrationValue`,`registrationValue`, `monthlyPayment`,`sucursal_id`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (4,'Quarta  Classe','0.0', '0.0','0.0', '0.0',1,1,1,NULL,1,'2019-11-25 17:00:00','2019-11-25 17:00:00','2019-11-25 17:00:00');
INSERT INTO `frequencies` (`level`,`description`,`specialHourMonthlyValue`,`recurigRegistrationValue`,`registrationValue`, `monthlyPayment`,`sucursal_id`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (5,'Quinta  Classe','0.0', '0.0','0.0', '0.0',1,1,1,NULL,1,'2019-11-25 17:00:00','2019-11-25 17:00:00','2019-11-25 17:00:00');
INSERT INTO `frequencies` (`level`,`description`,`specialHourMonthlyValue`,`recurigRegistrationValue`,`registrationValue`, `monthlyPayment`,`sucursal_id`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (6,'Sexta  Classe','0.0', '0.0','0.0', '0.0',1,1,1,NULL,1,'2019-11-25 17:00:00','2019-11-25 17:00:00','2019-11-25 17:00:00');
INSERT INTO `frequencies` (`level`,`description`,`specialHourMonthlyValue`,`recurigRegistrationValue`,`registrationValue`, `monthlyPayment`,`sucursal_id`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (7,'Sétima  Classe','0.0', '0.0','0.0', '0.0',1,1,1,NULL,1,'2019-11-25 17:00:00','2019-11-25 17:00:00','2019-11-25 17:00:00');
INSERT INTO `frequencies` (`level`,`description`,`specialHourMonthlyValue`,`recurigRegistrationValue`,`registrationValue`, `monthlyPayment`,`sucursal_id`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (1,'Primeiro  Ano','0.0', '0.0','0.0', '0.0',2,1,1,NULL,1,'2019-11-25 17:00:00','2019-11-25 17:00:00','2019-11-25 17:00:00');
INSERT INTO `frequencies` (`level`,`description`,`specialHourMonthlyValue`,`recurigRegistrationValue`,`registrationValue`, `monthlyPayment`,`sucursal_id`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (2,'Segundo Ano','0.0', '0.0', '0.0', '0.0',2,1,1,NULL,1,'2019-11-25 17:00:00','2019-11-25 17:00:00','2019-11-25 17:00:00');
INSERT INTO `frequencies` (`level`,`description`,`specialHourMonthlyValue`,`recurigRegistrationValue`,`registrationValue`, `monthlyPayment`,`sucursal_id`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (3,'Terceiro Ano','0.0', '0.0','0.0', '0.0',2,1,1,NULL,1,'2019-11-25 17:00:00','2019-11-25 17:00:00','2019-11-25 17:00:00');
INSERT INTO `frequencies` (`level`,`description`,`specialHourMonthlyValue`,`recurigRegistrationValue`,`registrationValue`, `monthlyPayment`,`sucursal_id`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (4,'Quarto Ano', '0.0', '0.0','0.0', '0.0',2,1,1,NULL,1,'2019-11-25 17:00:00','2019-11-25 17:00:00','2019-11-25 17:00:00');
INSERT INTO `frequencies` (`level`,`description`,`specialHourMonthlyValue`,`recurigRegistrationValue`,`registrationValue`, `monthlyPayment`,`sucursal_id`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (5,'Quinto Ano','0.0', '0.0','0.0', '0.0',2,1,1,NULL,1,'2019-11-25 17:00:00','2019-11-25 17:00:00','2019-11-25 17:00:00');
INSERT INTO `sge`.`paymentconfigs` (`smsSenderID`, `paymentStartDay`, `paymentEndDay`, `sucursal_id`, `active`, `created_by`, `activated_by`, `activation_date`, `createdAt`, `updatedAt`) VALUES ('LUZDODIA', '20', '5', '1', '1', '1', '1', '2019-12-14 12:00:00', '2019-12-14 12:00:00', '2019-12-14 12:00:00');
INSERT INTO `sge`.`paymentconfigs` (`smsSenderID`, `paymentStartDay`, `paymentEndDay`, `sucursal_id`, `active`, `created_by`, `activated_by`, `activation_date`, `createdAt`, `updatedAt`) VALUES ('LUZDODIA', '20', '5', '2', '1', '1', '1', '2019-12-14 12:00:00', '2019-12-14 12:00:00', '2019-12-14 12:00:00');
INSERT INTO `sge`.`transactions` (`code`, `description`, `active`, `created_by`, `activated_by`, `activation_date`, `createdAt`, `updatedAt`) VALUES ('ST_001', 'Cadastrar Estudante', '1', '1', '1', '2019-12-17 04:04:00', '2019-12-17 04:04:00', '2019-12-17 04:04:00');
INSERT INTO `sge`.`transactions` (`code`, `description`, `active`, `created_by`, `activated_by`, `activation_date`, `createdAt`, `updatedAt`) VALUES ('ST_002', 'Manter Estudante', '1', '1', '1', '2019-12-17 04:04:00', '2019-12-17 04:04:00', '2019-12-17 04:04:00');
INSERT INTO `sge`.`transactions` (`code`, `description`, `active`, `created_by`, `activated_by`, `activation_date`, `createdAt`, `updatedAt`) VALUES ('PY_001', 'Efectuar Pagamento', '1', '1', '1', '2019-12-17 04:04:00', '2019-12-17 04:04:00', '2019-12-17 04:04:00');
INSERT INTO `sge`.`transactions` (`code`, `description`, `active`, `created_by`, `activated_by`, `activation_date`, `createdAt`, `updatedAt`) VALUES ('PY_002', 'Ver Pagamentos Efectuados', '1', '1', '1', '2019-12-17 04:04:00', '2019-12-17 04:04:00', '2019-12-17 04:04:00');
INSERT INTO `sge`.`transactions` (`code`, `description`, `active`, `created_by`, `activated_by`, `activation_date`, `createdAt`, `updatedAt`) VALUES ('PY_002', 'Ver Pagamentos Atrasados', '1', '1', '1', '2019-12-17 04:04:00', '2019-12-17 04:04:00', '2019-12-17 04:04:00');
INSERT INTO `sge`.`transactions` (`code`, `description`, `active`, `created_by`, `activated_by`, `activation_date`, `createdAt`, `updatedAt`) VALUES ('CONF_001', 'Configurar Taxas', '1', '1', '1', '2019-12-17 04:04:00', '2019-12-17 04:04:00', '2019-12-17 04:04:00');
INSERT INTO `sge`.`transactions` (`code`, `description`, `active`, `created_by`, `activated_by`, `activation_date`, `createdAt`, `updatedAt`) VALUES ('USR_001', 'Cadastrar Utilizadores', '1', '1', '1', '2019-12-17 04:04:00', '2019-12-17 04:04:00', '2019-12-17 04:04:00');
INSERT INTO `sge`.`transactions` (`code`, `description`, `active`, `created_by`, `activated_by`, `activation_date`, `createdAt`, `updatedAt`) VALUES ('USR_002', 'Manter Utilizadores', '1', '1', '1', '2019-12-17 04:04:00', '2019-12-17 04:04:00', '2019-12-17 04:04:00');
INSERT INTO `sge`.`transactions` (`code`, `description`, `active`, `created_by`, `activated_by`, `activation_date`, `createdAt`, `updatedAt`) VALUES ('R_001', 'Emitir Comprovativo de Cadastro', '1', '1', '1', '2019-12-17 04:04:00', '2019-12-17 04:04:00', '2019-12-17 04:04:00');
INSERT INTO `sge`.`profiles` (`code`, `description`, `active`, `created_by`, `activated_by`, `activation_date`, `createdAt`, `updatedAt`) VALUES ('001', 'Funcionário(a)', '1', '1', '1', '2019-12-17 04:14:00', '2019-12-17 04:14:00', '2019-12-17 04:14:00');
INSERT INTO `sge`.`profiles` (`code`, `description`, `active`, `created_by`, `activated_by`, `activation_date`, `createdAt`, `updatedAt`) VALUES ('002', 'Director(a)', '1', '1', '1', '2019-12-17 04:14:00', '2019-12-17 04:14:00', '2019-12-17 04:14:00');
INSERT INTO `users` (`id`,`name`,`email`,`contact`,`address`,`picture`,`username`,`password`,`profile_id`,`active`,`created_by`,`updated_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (1,'Judiao Mbaua','','841143433','M. Gare','','admin','$2a$10$yslvK/ga6quWI3S2VTlHVe4VowZDTyzxK40bj53oOcb/9pxcomHO2',2,1,1,NULL,1,'2019-12-23 01:33:13','2019-12-23 01:33:13','2019-12-23 01:33:13');
INSERT INTO `usersucursals` (`user_id`,`sucursal_id`,`active`,`created_by`,`activated_by`,`activation_date`,`createdAt`,`updatedAt`) VALUES (1,1,1,1,1,'2019-12-23 01:33:13','2019-12-23 01:33:13','2019-12-23 01:33:13');


ALTER TABLE Students
ADD COLUMN syncStatus INT NOT NULL default 0;

ALTER TABLE Users
ADD COLUMN syncStatus INT NOT NULL default 0;

ALTER TABLE Payments
ADD COLUMN syncStatus INT NOT NULL default 0;

ALTER TABLE Cariers
ADD COLUMN syncStatus INT NOT NULL default 0;

ALTER TABLE Registrations
ADD COLUMN syncStatus INT NOT NULL default 0;

ALTER TABLE LoginInfos
ADD COLUMN syncStatus INT NOT NULL default 0;

ALTER TABLE Frequencies
ADD COLUMN syncStatus INT NOT NULL default 0;

ALTER TABLE PaymentConfigs
ADD COLUMN syncStatus INT NOT NULL default 0;

ALTER TABLE Profiles
ADD COLUMN syncStatus INT NOT NULL default 0;

ALTER TABLE ProfileTransactions
ADD COLUMN syncStatus INT NOT NULL default 0;

Update sge_teste.Students set studentNumber=concat("2020001",lpad(""+id,5,"0"));


CREATE TABLE `FineConfigs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `startDay` int(11) NOT NULL,
  `percentagem` int(11) NOT NULL,
  `endDay` int(11) NOT NULL,
  `sucursal_id` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `activated_by` int(11) NOT NULL,
  `activation_date` datetime NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sucursal_id` (`sucursal_id`),
  CONSTRAINT `FineConfigs_ibfk_1` FOREIGN KEY (`sucursal_id`) REFERENCES `Sucursals` (`id`)
) ENGINE=InnoDB;

